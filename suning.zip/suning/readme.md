URL :http://10.9.25.133:4001

Method :POST

DataType :

请求消息: JSON

响应消息: JSON

功能:

一：signIn.html
实现登录功能


二：signUp.html
实现注册功能

三：indexs.html
登录成功获取cookie展示首页 点击搜索框跳转商品列表页

四：index.html
获取商品分类及列表 点击商品图片跳转详情页 点击加入购物车进入购物车页面

五：itemInfo.html
详情页 可添加商品到购物车并跳转购物车页面

六：cart.html
购物车页面 完成购物车增删基本功能 点击付款跳转支付页


七：pay.html
完成支付并返回首页



